/*********************************************************************
 * (C) Copyright 2001 Albert Ludwigs University Freiburg
 *     Institute of Computer Science
 *
 * All rights reserved. Use of this software is permitted for 
 * non-commercial research purposes, and it may be copied only 
 * for that use.  All copies must include this copyright message.
 * This software is made available AS IS, and neither the authors
 * nor the  Albert Ludwigs University Freiburg make any warranty
 * about the software or its performance. 
 *********************************************************************/



/* 
 * C code for generating random logistics problems
 */


#include <stdlib.h>
#include <stdio.h>
#include <sys/timeb.h>
#include <string.h>


typedef unsigned char Bool;
#define TRUE 1
#define FALSE 0


/* command line
 */
void usage( void );
Bool process_command_line( int argc, char *argv[] );
Bool setup_city_sizes( int vec );


int rovers, bases;

int main(int argc, char * argv[]){

  int i;

  /* seed the random() function
   */
  struct timeb tp;
  ftime( & tp);
  srand(tp.millitm);

  /* command line treatment, first preset values
   */
  rovers = -1;
  bases = 4;

  if (argc == 1 || (argc == 2 && * ++argv[0] == '?')) {
    usage();
    exit(1);
  }
  if (!process_command_line(argc, argv)) {
    usage();
    exit(1);
  }

  printf("\n\n\n");

  printf("(define (problem roversEnMarte)");
  printf("\n(:domain marte)");

  printf("\n(:objects ");
  for (i = 0; i < bases; i++) {
    printf("b%d ", i);
  }
  printf("-base");
  printf("\n          ");

  for (i = 0; i < rovers; i++) {
    printf("r%d ", i);
  }
  printf("-rover");
  printf("\n)");

  printf("\n(:init");
  for (i = 0; i < bases; i++) {
    int nextBase = (i == bases-1) ? 0 : i+1; 
    printf("\n(conexion b%d b%d)", i, nextBase);
  }

  for (i = 0; i < bases; i++) {
    if (i < 2) {
      printf("\n(esAlmacen b%d)", i);
      printf("\n(= (suministrosEnBase b%d) %d)", i, rand()%15);
    } else {
      printf("\n(esAsentamiento b%d)", i);
      printf("\n(= (personasEnBase b%d) %d)", i, (i < 4) ? rand()%15 : 0);
    }
  }

  for (i = 0; i < rovers; i++) {
    printf("\n(roverEnBase r%d b%d)", i, rand() % bases);
    printf("\n(= (numeroDePersonas r%d) 0)", i);
    printf("\n(= (combustible r%d) %d)", i, 60 + rand()%240);
  }

  for (i = 0; i < bases; i++) {
    if (i > 3) {
      printf("\n(= (peticionSuministroBase b%d) %d)", i, 51 + rand()%950);
      printf("\n(= (prioridadSuministroBase b%d) %d)", i, 1 + rand()%3);
      printf("\n(= (peticionPersonaBase b%d) %d)", i, 51 + rand()%950);
      printf("\n(= (prioridadPersonaBase b%d) %d)", i, 1 + rand()%3);
    }
  }

  printf("\n(= (personasEnCirculacion) 0)");
  printf("\n(= (suministrosEnCirculacion) 0)");
  printf("\n(= (total-cost) 0)");
  printf("\n(= (penalizacion-total) 0)");

  printf("\n)");

  printf("\n(:goal");
  printf("\n(and (forall (?b - base) (and (or (not(esAsentamiento ?b)) (= (personasEnBase ?b) 0)) (or (not(esAlmacen ?b)) (= (suministrosEnBase ?b) 0)))) (= (suministrosEnCirculacion) 0) (= (personasEnCirculacion) 0))");
  printf("\n)");

  printf("\n)");



  printf("\n\n\n");

  exit(0);
}
  

void usage(void){
  printf("\nusage:\n");
  printf("\nOPTIONS   DESCRIPTIONS\n\n");
  printf("-b <num>    numero de bases\n");
  printf("-r <num>    numero de rovers (minimo 1)\n");
}

Bool process_command_line(int argc, char * argv[]) {

  char option;

  while (--argc && ++argv) {
    if ( * argv[0] != '-' || strlen( * argv) != 2) {
      return FALSE;
    }
    option = * ++argv[0];
    switch (option) {
      default: if (--argc && ++argv) {
        switch (option) {
        case 'b':
          sscanf( * argv, "%d", & bases);
          break;
        case 'r':
          sscanf( * argv, "%d", & rovers);
          break;
        default:
          printf("\n\nunknown option: %c entered\n\n", option);
          return FALSE;
        }
      } else {
        return FALSE;
      }
    }
  }
  if (rovers < 1) {
    return FALSE;
  }
  return TRUE;
}
